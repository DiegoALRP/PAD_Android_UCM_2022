package es.ucm.fdi.calculator;

public class Calculator {

    public float sum_2_num(float num_a, float num_b) {

        return num_a + num_b;
    }


}
